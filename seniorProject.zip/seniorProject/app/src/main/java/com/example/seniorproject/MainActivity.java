package com.example.seniorproject;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.RectF;
import android.net.Uri;
import android.os.Bundle;
import android.provider.MediaStore;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.IOException;
import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    final int IMAGE_REQ_CODE = 100, CAMERA_CLICK_CODE=101;
    final String MODEL_NAME = "raghad_model_new-fp16.tflite";

    Bitmap bitmap;
    Button imageCapture;
    ImageView imageView;
    Yolov5TFLiteDetector yolov5TFLiteDetector;

    Paint boxPaint = new Paint();
    Paint textPain = new Paint();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        imageView = findViewById(R.id.imageView);
        imageCapture = findViewById(R.id.captureButton);



        boxPaint.setStrokeWidth(5);
        boxPaint.setStyle(Paint.Style.STROKE);
        boxPaint.setColor(Color.RED);
        textPain.setTextSize(50);
        textPain.setColor(Color.RED);
        textPain.setStyle(Paint.Style.FILL);

        //initialize yolo model
        yolov5TFLiteDetector = new Yolov5TFLiteDetector();
        yolov5TFLiteDetector.setModelFile(MODEL_NAME);
        yolov5TFLiteDetector.initialModel(this);


        imageView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent();
                intent.setAction(Intent.ACTION_GET_CONTENT);
                intent.setType("image/*");
                startActivityForResult(intent, IMAGE_REQ_CODE);
            }
        });
        imageCapture.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
                startActivityForResult(intent, CAMERA_CLICK_CODE);
            }
        });
    }
    public void onClickButt1(View view){


        Intent intent= new Intent(this, MainActivity2.class);
        startActivity(intent);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);

        if(requestCode == IMAGE_REQ_CODE && data != null){
            Uri uri = data.getData();
            try {
                bitmap = MediaStore.Images.Media.getBitmap(this.getContentResolver(), uri);
                imageView.setImageBitmap(bitmap);
                Toast.makeText(this, "Image Selected successfully", Toast.LENGTH_SHORT).show();

                predict();
            } catch (IOException e) {
                throw new RuntimeException(e);
            }
        }
        else if(requestCode == CAMERA_CLICK_CODE && data != null){
            bitmap = (Bitmap) data.getExtras().get("data");
            Toast.makeText(this, "Image Captured", Toast.LENGTH_SHORT).show();
            imageView.setImageBitmap(bitmap);

            predict();
        }
    }

    void predict() {
        // load model and run prediction on it
        ArrayList<Recognition> predictions = yolov5TFLiteDetector.detect(bitmap);
        Bitmap mutableBitmap = bitmap.copy(Bitmap.Config.ARGB_8888, true);
        Canvas cropCanvas = new Canvas(mutableBitmap);
        String label = null;
        for (Recognition res : predictions) {
            RectF location = res.getLocation();
            label = res.getLabelName();
            float confidence = res.getConfidence();
            if (confidence < 0.1) {
                continue;
            }

            cropCanvas.drawRect((location.left / 320) * bitmap.getWidth(), (location.top / 320) * bitmap.getHeight(), (location.right / 320) * bitmap.getWidth(), (location.bottom / 320) * bitmap.getHeight(), boxPaint);
            cropCanvas.drawText(label + ":" + String.format("%.2f", confidence), (location.left / 320) * bitmap.getWidth(), (location.top / 320) * bitmap.getHeight(), textPain);

        }

        TextView txt = findViewById(R.id.trial);
        txt.setText(label);


        imageView.setImageBitmap(mutableBitmap);
    }
}